"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const handler = async (event) => {
    console.log('Received event:', JSON.stringify(event, null, 2));
    return {
        statusCode: 200,
        headers: {
            'Access-Control-Allow-Origin': 'http://localhost:4200',
            'Access-Control-Allow-Headers': 'Content-Type,x-dev-user',
            'Access-Control-Allow-Methods': 'GET,POST,PUT,OPTIONS',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify([
            {
                id: '1',
                title: 'Test book from Lambda',
                author: 'Lambda',
                format: 'Paperback',
                price: 15,
                copies: 3
            }
        ])
    };
};
exports.handler = handler;
