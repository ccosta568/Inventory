"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
var books_1 = require("./handlers/books");
Object.defineProperty(exports, "handler", { enumerable: true, get: function () { return books_1.handler; } });
