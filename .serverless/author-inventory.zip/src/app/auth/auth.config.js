"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildAuthConfig = exports.COGNITO_CONFIG_ID = void 0;
const angular_auth_oidc_client_1 = require("angular-auth-oidc-client");
const environment_1 = require("../../environments/environment");
exports.COGNITO_CONFIG_ID = 'cognito';
function buildAuthority() {
    if (environment_1.environment.oidc?.authority) {
        return environment_1.environment.oidc.authority;
    }
    const poolId = environment_1.environment.cognito?.userPoolId || 'us-east-1_example';
    // Fallback to the default us-east-1 region when no explicit authority is provided.
    return `https://cognito-idp.us-east-1.amazonaws.com/${poolId}`;
}
function buildAuthConfig() {
    const apiBase = (environment_1.environment.apiBaseUrl ?? '').replace(/\/$/, '');
    const cognito = environment_1.environment.cognito ?? {};
    const oidc = environment_1.environment.oidc ?? {};
    const scope = oidc.scope || cognito.scope || 'openid profile email';
    const redirectUrl = oidc.redirectUrl || cognito.redirectUrl || 'http://localhost:4200';
    const logoutUrl = oidc.postLogoutRedirectUri || cognito.logoutUrl || cognito.redirectUrl || 'http://localhost:4200';
    const clientId = oidc.clientId || cognito.clientId || 'replace-with-cognito-client-id';
    return {
        config: {
            configId: exports.COGNITO_CONFIG_ID,
            authority: buildAuthority(),
            redirectUrl,
            postLogoutRedirectUri: logoutUrl,
            clientId,
            scope,
            responseType: oidc.responseType || 'code',
            silentRenew: true,
            useRefreshToken: true,
            secureRoutes: apiBase ? [apiBase] : [],
            unauthorizedRoute: '/unauthorized',
            logLevel: environment_1.environment.production ? angular_auth_oidc_client_1.LogLevel.Error : angular_auth_oidc_client_1.LogLevel.Debug
        }
    };
}
exports.buildAuthConfig = buildAuthConfig;
