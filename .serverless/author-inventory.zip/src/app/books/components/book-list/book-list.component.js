"use strict";
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __setFunctionName = (this && this.__setFunctionName) || function (f, name, prefix) {
    if (typeof name === "symbol") name = name.description ? "[".concat(name.description, "]") : "";
    return Object.defineProperty(f, "name", { configurable: true, value: prefix ? "".concat(prefix, " ", name) : name });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BookListComponent = void 0;
const core_1 = require("@angular/core");
const common_1 = require("@angular/common");
let BookListComponent = (() => {
    let _classDecorators = [(0, core_1.Component)({
            selector: 'app-book-list',
            standalone: true,
            imports: [common_1.CommonModule],
            templateUrl: './book-list.component.html',
            styleUrls: ['./book-list.component.scss']
        })];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _books_decorators;
    let _books_initializers = [];
    let _books_extraInitializers = [];
    let _savingMap_decorators;
    let _savingMap_initializers = [];
    let _savingMap_extraInitializers = [];
    let _adjust_decorators;
    let _adjust_initializers = [];
    let _adjust_extraInitializers = [];
    let _remove_decorators;
    let _remove_initializers = [];
    let _remove_extraInitializers = [];
    var BookListComponent = _classThis = class {
        trackById(_index, book) {
            return book.id;
        }
        emitAdjust(bookId, delta) {
            this.adjust.emit({ bookId, delta });
        }
        emitRemove(bookId) {
            this.remove.emit(bookId);
        }
        constructor() {
            this.books = __runInitializers(this, _books_initializers, []);
            this.savingMap = (__runInitializers(this, _books_extraInitializers), __runInitializers(this, _savingMap_initializers, {}));
            this.adjust = (__runInitializers(this, _savingMap_extraInitializers), __runInitializers(this, _adjust_initializers, new core_1.EventEmitter()));
            this.remove = (__runInitializers(this, _adjust_extraInitializers), __runInitializers(this, _remove_initializers, new core_1.EventEmitter()));
            __runInitializers(this, _remove_extraInitializers);
        }
    };
    __setFunctionName(_classThis, "BookListComponent");
    (() => {
        const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(null) : void 0;
        _books_decorators = [(0, core_1.Input)()];
        _savingMap_decorators = [(0, core_1.Input)()];
        _adjust_decorators = [(0, core_1.Output)()];
        _remove_decorators = [(0, core_1.Output)()];
        __esDecorate(null, null, _books_decorators, { kind: "field", name: "books", static: false, private: false, access: { has: obj => "books" in obj, get: obj => obj.books, set: (obj, value) => { obj.books = value; } }, metadata: _metadata }, _books_initializers, _books_extraInitializers);
        __esDecorate(null, null, _savingMap_decorators, { kind: "field", name: "savingMap", static: false, private: false, access: { has: obj => "savingMap" in obj, get: obj => obj.savingMap, set: (obj, value) => { obj.savingMap = value; } }, metadata: _metadata }, _savingMap_initializers, _savingMap_extraInitializers);
        __esDecorate(null, null, _adjust_decorators, { kind: "field", name: "adjust", static: false, private: false, access: { has: obj => "adjust" in obj, get: obj => obj.adjust, set: (obj, value) => { obj.adjust = value; } }, metadata: _metadata }, _adjust_initializers, _adjust_extraInitializers);
        __esDecorate(null, null, _remove_decorators, { kind: "field", name: "remove", static: false, private: false, access: { has: obj => "remove" in obj, get: obj => obj.remove, set: (obj, value) => { obj.remove = value; } }, metadata: _metadata }, _remove_initializers, _remove_extraInitializers);
        __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
        BookListComponent = _classThis = _classDescriptor.value;
        if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        __runInitializers(_classThis, _classExtraInitializers);
    })();
    return BookListComponent = _classThis;
})();
exports.BookListComponent = BookListComponent;
