"use strict";
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __setFunctionName = (this && this.__setFunctionName) || function (f, name, prefix) {
    if (typeof name === "symbol") name = name.description ? "[".concat(name.description, "]") : "";
    return Object.defineProperty(f, "name", { configurable: true, value: prefix ? "".concat(prefix, " ", name) : name });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BookListComponent = void 0;
const core_1 = require("@angular/core");
const common_1 = require("@angular/common");
const forms_1 = require("@angular/forms");
let BookListComponent = (() => {
    let _classDecorators = [(0, core_1.Component)({
            selector: 'app-book-list',
            standalone: true,
            imports: [common_1.CommonModule, forms_1.FormsModule],
            templateUrl: './book-list.component.html',
            styleUrls: ['./book-list.component.scss']
        })];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _books_decorators;
    let _books_initializers = [];
    let _books_extraInitializers = [];
    let _bookSavingMap_decorators;
    let _bookSavingMap_initializers = [];
    let _bookSavingMap_extraInitializers = [];
    let _tierSavingMap_decorators;
    let _tierSavingMap_initializers = [];
    let _tierSavingMap_extraInitializers = [];
    let _adjustTier_decorators;
    let _adjustTier_initializers = [];
    let _adjustTier_extraInitializers = [];
    let _addTier_decorators;
    let _addTier_initializers = [];
    let _addTier_extraInitializers = [];
    let _remove_decorators;
    let _remove_initializers = [];
    let _remove_extraInitializers = [];
    var BookListComponent = _classThis = class {
        constructor() {
            this.books = __runInitializers(this, _books_initializers, []);
            this.bookSavingMap = (__runInitializers(this, _books_extraInitializers), __runInitializers(this, _bookSavingMap_initializers, {}));
            this.tierSavingMap = (__runInitializers(this, _bookSavingMap_extraInitializers), __runInitializers(this, _tierSavingMap_initializers, {}));
            this.adjustTier = (__runInitializers(this, _tierSavingMap_extraInitializers), __runInitializers(this, _adjustTier_initializers, new core_1.EventEmitter()));
            this.addTier = (__runInitializers(this, _adjustTier_extraInitializers), __runInitializers(this, _addTier_initializers, new core_1.EventEmitter()));
            this.remove = (__runInitializers(this, _addTier_extraInitializers), __runInitializers(this, _remove_initializers, new core_1.EventEmitter()));
            this.newTierState = (__runInitializers(this, _remove_extraInitializers), {});
        }
        ensureTierState(bookId) {
            if (!this.newTierState[bookId]) {
                this.newTierState[bookId] = { price: null, copies: null, notes: '' };
            }
            return this.newTierState[bookId];
        }
        getTierState(bookId) {
            return this.ensureTierState(bookId);
        }
        trackById(_index, book) {
            return book.id;
        }
        tierKey(bookId, tierId) {
            return `${bookId}:${tierId}`;
        }
        emitAdjustTier(book, tier, delta) {
            this.adjustTier.emit({
                bookId: tier.bookId || book.id,
                tierId: tier.tierId,
                delta,
                price: tier.price
            });
        }
        emitRemove(bookId) {
            this.remove.emit(bookId);
        }
        updateTierState(bookId, key, value) {
            const existing = this.ensureTierState(bookId);
            this.newTierState[bookId] = { ...existing, [key]: value };
        }
        submitNewTier(bookId) {
            const state = this.ensureTierState(bookId);
            const price = Number(state.price ?? 0);
            const copies = Number(state.copies ?? 0);
            if (price <= 0) {
                alert('Enter a valid price for the new tier.');
                return;
            }
            this.addTier.emit({ bookId, price, copies: Math.max(0, copies), notes: state.notes?.trim() || '' });
            this.newTierState[bookId] = { price: null, copies: null, notes: '' };
        }
    };
    __setFunctionName(_classThis, "BookListComponent");
    (() => {
        const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(null) : void 0;
        _books_decorators = [(0, core_1.Input)()];
        _bookSavingMap_decorators = [(0, core_1.Input)()];
        _tierSavingMap_decorators = [(0, core_1.Input)()];
        _adjustTier_decorators = [(0, core_1.Output)()];
        _addTier_decorators = [(0, core_1.Output)()];
        _remove_decorators = [(0, core_1.Output)()];
        __esDecorate(null, null, _books_decorators, { kind: "field", name: "books", static: false, private: false, access: { has: obj => "books" in obj, get: obj => obj.books, set: (obj, value) => { obj.books = value; } }, metadata: _metadata }, _books_initializers, _books_extraInitializers);
        __esDecorate(null, null, _bookSavingMap_decorators, { kind: "field", name: "bookSavingMap", static: false, private: false, access: { has: obj => "bookSavingMap" in obj, get: obj => obj.bookSavingMap, set: (obj, value) => { obj.bookSavingMap = value; } }, metadata: _metadata }, _bookSavingMap_initializers, _bookSavingMap_extraInitializers);
        __esDecorate(null, null, _tierSavingMap_decorators, { kind: "field", name: "tierSavingMap", static: false, private: false, access: { has: obj => "tierSavingMap" in obj, get: obj => obj.tierSavingMap, set: (obj, value) => { obj.tierSavingMap = value; } }, metadata: _metadata }, _tierSavingMap_initializers, _tierSavingMap_extraInitializers);
        __esDecorate(null, null, _adjustTier_decorators, { kind: "field", name: "adjustTier", static: false, private: false, access: { has: obj => "adjustTier" in obj, get: obj => obj.adjustTier, set: (obj, value) => { obj.adjustTier = value; } }, metadata: _metadata }, _adjustTier_initializers, _adjustTier_extraInitializers);
        __esDecorate(null, null, _addTier_decorators, { kind: "field", name: "addTier", static: false, private: false, access: { has: obj => "addTier" in obj, get: obj => obj.addTier, set: (obj, value) => { obj.addTier = value; } }, metadata: _metadata }, _addTier_initializers, _addTier_extraInitializers);
        __esDecorate(null, null, _remove_decorators, { kind: "field", name: "remove", static: false, private: false, access: { has: obj => "remove" in obj, get: obj => obj.remove, set: (obj, value) => { obj.remove = value; } }, metadata: _metadata }, _remove_initializers, _remove_extraInitializers);
        __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
        BookListComponent = _classThis = _classDescriptor.value;
        if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        __runInitializers(_classThis, _classExtraInitializers);
    })();
    return BookListComponent = _classThis;
})();
exports.BookListComponent = BookListComponent;
