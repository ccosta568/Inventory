"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.appConfig = void 0;
const router_1 = require("@angular/router");
const http_1 = require("@angular/common/http");
const platform_browser_1 = require("@angular/platform-browser");
const angular_auth_oidc_client_1 = require("angular-auth-oidc-client");
const app_routes_1 = require("./app.routes");
const auth_config_1 = require("./auth/auth.config");
const auth_interceptor_1 = require("./auth/auth.interceptor");
exports.appConfig = {
    providers: [
        (0, router_1.provideRouter)(app_routes_1.routes),
        (0, platform_browser_1.provideClientHydration)(),
        (0, http_1.provideHttpClient)((0, http_1.withFetch)(), (0, http_1.withInterceptorsFromDi)()),
        (0, angular_auth_oidc_client_1.provideAuth)((0, auth_config_1.buildAuthConfig)()),
        {
            provide: http_1.HTTP_INTERCEPTORS,
            useClass: auth_interceptor_1.AuthInterceptor,
            multi: true
        }
    ]
};
