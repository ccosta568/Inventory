"use strict";
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __setFunctionName = (this && this.__setFunctionName) || function (f, name, prefix) {
    if (typeof name === "symbol") name = name.description ? "[".concat(name.description, "]") : "";
    return Object.defineProperty(f, "name", { configurable: true, value: prefix ? "".concat(prefix, " ", name) : name });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BookApiService = void 0;
const core_1 = require("@angular/core");
const rxjs_1 = require("rxjs");
const operators_1 = require("rxjs/operators");
const environment_1 = require("../../environments/environment");
let BookApiService = (() => {
    let _classDecorators = [(0, core_1.Injectable)({ providedIn: 'root' })];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    var BookApiService = _classThis = class {
        constructor(http) {
            this.http = http;
            this.base = (environment_1.environment?.apiBaseUrl ?? '').replace(/\/$/, '');
        }
        normalize(item) {
            if (!item?.id)
                return null;
            const tiers = (item.priceTiers || []).map((tier) => ({
                bookId: tier.bookId || item.id,
                tierId: tier.tierId,
                price: Number(tier.price ?? 0),
                copiesOnHand: Number(tier.copiesOnHand ?? 0),
                notes: tier.notes ?? '',
                createdAt: tier.createdAt,
                updatedAt: tier.updatedAt
            }));
            if (!tiers.length) {
                const fallbackCopies = typeof item.copies === 'number'
                    ? item.copies
                    : typeof item.copiesOnHand === 'number'
                        ? item.copiesOnHand
                        : 0;
                tiers.push({
                    bookId: item.id,
                    tierId: item.id,
                    price: Number(item.price ?? 0),
                    copiesOnHand: fallbackCopies,
                    notes: item.notes ?? '',
                    createdAt: item.createdAt,
                    updatedAt: item.updatedAt
                });
            }
            const totalOnHand = typeof item.totalOnHand === 'number'
                ? item.totalOnHand
                : tiers.reduce((sum, tier) => sum + tier.copiesOnHand, 0);
            return {
                id: item.id,
                title: item.title || 'Untitled',
                author: item.author || '',
                format: item.format || 'Paperback',
                notes: item.notes ?? '',
                priceTiers: tiers,
                totalOnHand,
                createdAt: item.createdAt ?? new Date().toISOString(),
                updatedAt: item.updatedAt ?? item.createdAt
            };
        }
        getBooks() {
            if (!this.base) {
                console.warn('[BookApi] No API base URL configured; returning empty list');
                return (0, rxjs_1.of)([]);
            }
            return this.http
                .get(`${this.base}/books`)
                .pipe((0, operators_1.map)((items) => (items || [])
                .map((item) => this.normalize(item))
                .filter((book) => !!book)), (0, operators_1.catchError)((err) => {
                console.error('[BookApi] getBooks failed', err);
                return (0, rxjs_1.throwError)(() => err);
            }));
        }
        createBook(payload) {
            if (!this.base) {
                return (0, rxjs_1.throwError)(() => new Error('API base URL is not configured'));
            }
            const body = {
                title: payload.title,
                author: payload.author,
                format: payload.format,
                price: payload.price,
                copies: payload.copies,
                notes: payload.notes ?? '',
                tierNotes: payload.tierNotes ?? payload.notes ?? ''
            };
            return this.http
                .post(`${this.base}/books`, body)
                .pipe((0, operators_1.map)((item) => {
                const candidate = Array.isArray(item) ? item[0] : item;
                const normalized = this.normalize(candidate);
                if (!normalized) {
                    throw new Error('API returned an unexpected book shape');
                }
                return normalized;
            }), (0, operators_1.catchError)((err) => {
                console.error('[BookApi] createBook failed', err);
                return (0, rxjs_1.throwError)(() => err);
            }));
        }
        createPriceTier(bookId, tier) {
            if (!this.base) {
                return (0, rxjs_1.throwError)(() => new Error('API base URL is not configured'));
            }
            const body = {
                price: tier.price,
                copies: tier.copies,
                copiesOnHand: tier.copies,
                notes: tier.notes ?? '',
                tierNotes: tier.notes ?? ''
            };
            return this.http
                .post(`${this.base}/books/${bookId}/tiers`, body)
                .pipe((0, operators_1.map)((item) => {
                const normalized = this.normalize(item);
                if (!normalized) {
                    throw new Error('API returned an unexpected book shape');
                }
                return normalized;
            }), (0, operators_1.catchError)((err) => {
                console.error('[BookApi] createPriceTier failed', err);
                return (0, rxjs_1.throwError)(() => err);
            }));
        }
        deleteBook(id) {
            if (!this.base) {
                return (0, rxjs_1.throwError)(() => new Error('API base URL is not configured'));
            }
            return this.http.delete(`${this.base}/books/${id}`).pipe((0, operators_1.catchError)((err) => {
                console.error('[BookApi] deleteBook failed', err);
                return (0, rxjs_1.throwError)(() => err);
            }));
        }
        adjustTierStock(bookId, tierId, delta, price) {
            if (!this.base) {
                return (0, rxjs_1.throwError)(() => new Error('API base URL is not configured'));
            }
            const payload = { delta, tierId };
            if (typeof price === 'number') {
                payload['price'] = price;
            }
            return this.http
                .post(`${this.base}/books/${bookId}/adjust-stock`, payload)
                .pipe((0, operators_1.map)((item) => {
                const normalized = this.normalize(item);
                if (!normalized) {
                    throw new Error('API returned an unexpected book shape');
                }
                return normalized;
            }), (0, operators_1.catchError)((err) => {
                console.error('[BookApi] adjustTierStock failed', err);
                return (0, rxjs_1.throwError)(() => err);
            }));
        }
    };
    __setFunctionName(_classThis, "BookApiService");
    (() => {
        const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(null) : void 0;
        __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
        BookApiService = _classThis = _classDescriptor.value;
        if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        __runInitializers(_classThis, _classExtraInitializers);
    })();
    return BookApiService = _classThis;
})();
exports.BookApiService = BookApiService;
