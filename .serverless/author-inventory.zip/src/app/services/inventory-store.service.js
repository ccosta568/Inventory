"use strict";
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __setFunctionName = (this && this.__setFunctionName) || function (f, name, prefix) {
    if (typeof name === "symbol") name = name.description ? "[".concat(name.description, "]") : "";
    return Object.defineProperty(f, "name", { configurable: true, value: prefix ? "".concat(prefix, " ", name) : name });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InventoryStoreService = void 0;
const core_1 = require("@angular/core");
const rxjs_1 = require("rxjs");
const environment_1 = require("../../environments/environment");
const STORAGE_KEY = 'authorInventory_v1';
const QUEUE_KEY = 'authorInventory_pending_v1';
let InventoryStoreService = (() => {
    let _classDecorators = [(0, core_1.Injectable)({ providedIn: 'root' })];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    var InventoryStoreService = _classThis = class {
        constructor(bookApi) {
            this.bookApi = bookApi;
            this.state = { books: [], events: [] };
            this.booksSubject = new rxjs_1.BehaviorSubject([]);
            this.books$ = this.booksSubject.asObservable();
            this.eventsSubject = new rxjs_1.BehaviorSubject([]);
            this.events$ = this.eventsSubject.asObservable();
            this.syncStatusSubject = new rxjs_1.BehaviorSubject({ pending: false, queueSize: 0 });
            this.syncStatus$ = this.syncStatusSubject.asObservable();
            this.pendingCreates = [];
            this.syncing = false;
            this.loadState();
            this.emitState();
            this.loadQueue();
            this.listenForOnline();
            void this.syncFromApi();
        }
        // ---------------------------------------------------------------------------
        // Persistence helpers
        // ---------------------------------------------------------------------------
        hasStorage() {
            return typeof window !== 'undefined' && typeof localStorage !== 'undefined';
        }
        loadState() {
            if (!this.hasStorage())
                return;
            try {
                const raw = localStorage.getItem(STORAGE_KEY);
                if (raw) {
                    this.state = JSON.parse(raw);
                }
            }
            catch (err) {
                console.error('Failed to load inventory state', err);
                this.state = { books: [], events: [] };
            }
        }
        saveState() {
            if (!this.hasStorage())
                return;
            localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
        }
        emitState() {
            this.booksSubject.next([...this.state.books]);
            const events = [...this.state.events].sort((a, b) => (b.date || '').localeCompare(a.date || ''));
            this.eventsSubject.next(events);
        }
        persistState() {
            this.saveState();
            this.emitState();
        }
        loadQueue() {
            if (!this.hasStorage())
                return;
            try {
                const raw = localStorage.getItem(QUEUE_KEY);
                if (raw) {
                    this.pendingCreates = JSON.parse(raw);
                }
            }
            catch (err) {
                console.error('Failed to parse pending queue', err);
                this.pendingCreates = [];
            }
            this.updateSyncStatus();
        }
        saveQueue() {
            if (!this.hasStorage())
                return;
            localStorage.setItem(QUEUE_KEY, JSON.stringify(this.pendingCreates));
            this.updateSyncStatus();
        }
        listenForOnline() {
            if (typeof window === 'undefined')
                return;
            window.addEventListener('online', () => void this.syncFromApi(true));
        }
        isApiConfigured() {
            return !!environment_1.environment?.apiBaseUrl;
        }
        // ---------------------------------------------------------------------------
        // Sync / queue management
        // ---------------------------------------------------------------------------
        async syncFromApi(force = false) {
            if (!this.isApiConfigured())
                return;
            if (this.syncing && !force)
                return;
            this.syncing = true;
            this.updateSyncStatus(true);
            try {
                const books = await (0, rxjs_1.firstValueFrom)(this.bookApi.getBooks());
                if (Array.isArray(books) && books.length) {
                    // Merge remote records with existing local metadata (notes/format/etc.)
                    const merged = books.map((remote) => {
                        const local = this.state.books.find((b) => b.id === remote.id);
                        return { ...local, ...remote };
                    });
                    this.state.books = merged;
                    this.persistState();
                }
                await this.flushPendingCreates();
                this.updateSyncStatus(false, Date.now());
            }
            catch (err) {
                console.error('Failed to sync books', err);
                this.updateSyncStatus(false, undefined, err?.message || 'Unable to sync with API.');
            }
            finally {
                this.syncing = false;
            }
        }
        async flushPendingCreates() {
            if (!this.isApiConfigured())
                return;
            if (!this.pendingCreates.length)
                return;
            const queue = [...this.pendingCreates];
            this.pendingCreates = [];
            this.saveQueue();
            for (const item of queue) {
                try {
                    const remote = await (0, rxjs_1.firstValueFrom)(this.bookApi.createBook(item.title, item.author));
                    this.replaceTempBook(item.tempId, remote);
                }
                catch (err) {
                    console.error('Failed to flush book create, re-queueing', err);
                    this.pendingCreates.push(item);
                }
            }
            this.saveQueue();
        }
        updateSyncStatus(pending = false, lastSuccess, lastError) {
            this.syncStatusSubject.next({
                pending,
                queueSize: this.pendingCreates.length,
                lastSuccess: lastSuccess ?? this.syncStatusSubject.value.lastSuccess,
                lastError: lastError ?? null
            });
        }
        async syncNow() {
            await this.syncFromApi(true);
        }
        // ---------------------------------------------------------------------------
        // Books
        // ---------------------------------------------------------------------------
        getBooks() {
            return [...this.state.books];
        }
        getBookById(id) {
            return this.state.books.find((b) => b.id === id);
        }
        upsertBook(book) {
            const idx = this.state.books.findIndex((b) => b.id === book.id);
            if (idx === -1) {
                this.state.books.push(book);
            }
            else {
                this.state.books[idx] = { ...this.state.books[idx], ...book };
            }
            this.persistState();
        }
        replaceTempBook(tempId, remote) {
            const idx = this.state.books.findIndex((b) => b.id === tempId);
            if (idx === -1) {
                this.state.books.push(remote);
            }
            else {
                this.state.books[idx] = { ...this.state.books[idx], ...remote, id: remote.id };
            }
            this.persistState();
        }
        generateId() {
            try {
                return crypto.randomUUID();
            }
            catch {
                return Math.random().toString(36).slice(2) + Date.now().toString(36);
            }
        }
        async addBook(partial) {
            const temp = {
                id: this.generateId(),
                title: partial.title,
                author: partial.author,
                format: partial.format ?? 'paperback',
                price: partial.price,
                copiesOnHand: partial.copiesOnHand ?? 0,
                notes: partial.notes
            };
            this.upsertBook(temp);
            if (!this.isApiConfigured()) {
                return temp;
            }
            try {
                const remote = await (0, rxjs_1.firstValueFrom)(this.bookApi.createBook(partial.title, partial.author));
                this.replaceTempBook(temp.id, remote);
                return remote;
            }
            catch (err) {
                console.warn('API create failed, queued for retry.', err);
                this.pendingCreates.push({ tempId: temp.id, title: partial.title, author: partial.author });
                this.saveQueue();
                this.updateSyncStatus();
                return temp;
            }
        }
        async updateBook(id, changes) {
            const existing = this.getBookById(id);
            if (!existing)
                return null;
            const updated = { ...existing, ...changes };
            this.upsertBook(updated);
            return updated;
        }
        async adjustCopies(id, delta) {
            const book = this.getBookById(id);
            if (!book)
                return null;
            const next = Math.max(0, (book.copiesOnHand ?? 0) + delta);
            const updated = { ...book, copiesOnHand: next };
            this.upsertBook(updated);
            return updated;
        }
        deleteBook(id) {
            this.state.books = this.state.books.filter((b) => b.id !== id);
            this.persistState();
        }
        // ---------------------------------------------------------------------------
        // Events (local only for show mode/reporting)
        // ---------------------------------------------------------------------------
        getEvents() {
            return [...this.eventsSubject.value];
        }
        addEventSale(partial, applyToInventory = true) {
            const event = { id: this.generateId(), ...partial };
            this.state.events.push(event);
            if (applyToInventory) {
                this.applyEventToInventory(event);
            }
            this.persistState();
            return event;
        }
        async applyEvent(eventId) {
            const event = this.state.events.find((e) => e.id === eventId);
            if (!event)
                return;
            this.applyEventToInventory(event);
        }
        applyEventToInventory(event) {
            event.lines?.forEach((line) => this.decrementLocalCopies(line));
            this.persistState();
        }
        decrementLocalCopies(line) {
            if (!line.bookId || !line.qtySold)
                return;
            const book = this.getBookById(line.bookId);
            if (!book)
                return;
            const next = Math.max(0, (book.copiesOnHand ?? 0) - Math.abs(line.qtySold));
            this.upsertBook({ ...book, copiesOnHand: next });
        }
        // ---------------------------------------------------------------------------
        // Utilities
        // ---------------------------------------------------------------------------
        exportState() {
            return JSON.stringify(this.state, null, 2);
        }
        importState(json) {
            const parsed = JSON.parse(json);
            if (!parsed || !Array.isArray(parsed.books) || !Array.isArray(parsed.events)) {
                throw new Error('Invalid inventory data');
            }
            this.state = parsed;
            this.persistState();
        }
        clearAll() {
            this.state = { books: [], events: [] };
            this.pendingCreates = [];
            this.saveQueue();
            this.persistState();
        }
    };
    __setFunctionName(_classThis, "InventoryStoreService");
    (() => {
        const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(null) : void 0;
        __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
        InventoryStoreService = _classThis = _classDescriptor.value;
        if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        __runInitializers(_classThis, _classExtraInitializers);
    })();
    return InventoryStoreService = _classThis;
})();
exports.InventoryStoreService = InventoryStoreService;
