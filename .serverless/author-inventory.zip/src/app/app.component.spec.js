"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const testing_1 = require("@angular/core/testing");
const rxjs_1 = require("rxjs");
const app_component_1 = require("./app.component");
const inventory_store_service_1 = require("./services/inventory-store.service");
class InventoryStoreStub {
    constructor() {
        this.syncStatus$ = (0, rxjs_1.of)({ pending: false, queueSize: 0 });
        this.syncNow = () => Promise.resolve();
    }
}
describe('AppComponent', () => {
    beforeEach(async () => {
        await testing_1.TestBed.configureTestingModule({
            imports: [app_component_1.AppComponent],
            providers: [
                { provide: inventory_store_service_1.InventoryStoreService, useClass: InventoryStoreStub }
            ]
        }).compileComponents();
    });
    it('should create the app shell', () => {
        const fixture = testing_1.TestBed.createComponent(app_component_1.AppComponent);
        const app = fixture.componentInstance;
        expect(app).toBeTruthy();
    });
    it('should render the brand heading', () => {
        const fixture = testing_1.TestBed.createComponent(app_component_1.AppComponent);
        fixture.detectChanges();
        const compiled = fixture.nativeElement;
        expect(compiled.querySelector('h1')?.textContent).toContain('Inventory & Sales');
    });
});
