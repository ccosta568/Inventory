"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.routes = void 0;
const books_page_component_1 = require("./books/books-page.component");
const show_mode_component_1 = require("./show-mode/show-mode.component");
const reports_page_component_1 = require("./reports/reports-page.component");
const unauthorized_component_1 = require("./unauthorized/unauthorized.component");
exports.routes = [
    { path: '', redirectTo: 'books', pathMatch: 'full' },
    {
        path: 'books',
        component: books_page_component_1.BooksPageComponent
    },
    {
        path: 'show',
        component: show_mode_component_1.ShowModeComponent
    },
    {
        path: 'reports',
        component: reports_page_component_1.ReportsPageComponent
    },
    { path: 'unauthorized', component: unauthorized_component_1.UnauthorizedComponent }
];
