"use strict";
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __setFunctionName = (this && this.__setFunctionName) || function (f, name, prefix) {
    if (typeof name === "symbol") name = name.description ? "[".concat(name.description, "]") : "";
    return Object.defineProperty(f, "name", { configurable: true, value: prefix ? "".concat(prefix, " ", name) : name });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShowModeComponent = void 0;
const core_1 = require("@angular/core");
const common_1 = require("@angular/common");
const forms_1 = require("@angular/forms");
const operators_1 = require("rxjs/operators");
let ShowModeComponent = (() => {
    let _classDecorators = [(0, core_1.Component)({
            selector: 'app-show-mode',
            standalone: true,
            imports: [common_1.CommonModule, forms_1.FormsModule],
            templateUrl: './show-mode.component.html',
            styleUrls: ['./show-mode.component.scss']
        })];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    var ShowModeComponent = _classThis = class {
        constructor(store) {
            this.store = store;
            this.cards$ = this.store.books$.pipe((0, operators_1.map)((books) => (books || []).flatMap((book) => (book.priceTiers || [])
                .filter((tier) => (tier.copiesOnHand ?? 0) > 0)
                .map((tier) => ({
                key: `${tier.bookId || book.id}:${tier.tierId}`,
                bookId: book.id,
                tierId: tier.tierId,
                tierBookId: tier.bookId || book.id,
                title: book.title,
                format: book.format,
                price: tier.price,
                copiesOnHand: tier.copiesOnHand,
                notes: tier.notes
            })))));
            this.eventName = '';
            this.eventDate = new Date().toISOString().split('T')[0];
            this.notes = '';
            this.saving = false;
            this.message = null;
            this.error = null;
            this.selections = {};
        }
        tierKey(card) {
            return card.key;
        }
        currentSelection(card) {
            return this.selections[this.tierKey(card)] || 0;
        }
        canIncrement(card) {
            return this.currentSelection(card) < card.copiesOnHand;
        }
        adjustSelection(card, delta) {
            const key = this.tierKey(card);
            const current = this.currentSelection(card);
            const max = Math.max(0, card.copiesOnHand);
            const next = Math.min(max, Math.max(0, current + delta));
            if (next === 0) {
                delete this.selections[key];
            }
            else {
                this.selections[key] = next;
            }
        }
        get hasSelection() {
            return Object.keys(this.selections).length > 0;
        }
        async logEvent() {
            if (!this.eventName.trim() || !this.eventDate) {
                this.error = 'Event name and date are required.';
                return;
            }
            if (!this.hasSelection) {
                this.error = 'Select at least one sale.';
                return;
            }
            const lines = Object.entries(this.selections)
                .map(([key, qty]) => {
                const [tierBookId, tierId] = key.split(':');
                const book = this.store.getBooks().find((candidate) => candidate.priceTiers.some((tier) => tier.tierId === tierId));
                const tier = book?.priceTiers.find((candidate) => candidate.tierId === tierId);
                if (tier) {
                    return {
                        bookId: tier.bookId || tierBookId,
                        tierId,
                        price: tier.price,
                        qtySold: qty
                    };
                }
                return null;
            })
                .filter((line) => !!line);
            if (!lines.length) {
                this.error = 'Selected price tiers could not be resolved. Please refresh inventory.';
                return;
            }
            this.saving = true;
            this.error = null;
            this.message = null;
            try {
                await this.store.addEventSale({
                    eventName: this.eventName.trim(),
                    date: this.eventDate,
                    lines,
                    notes: this.notes || undefined
                }, true);
                this.selections = {};
                this.eventName = '';
                this.notes = '';
                this.message = 'Event logged and applied to inventory.';
            }
            catch (err) {
                console.error('Failed to log event', err);
                this.error = err?.message || 'Failed to log event.';
            }
            finally {
                this.saving = false;
            }
        }
    };
    __setFunctionName(_classThis, "ShowModeComponent");
    (() => {
        const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(null) : void 0;
        __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
        ShowModeComponent = _classThis = _classDescriptor.value;
        if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        __runInitializers(_classThis, _classExtraInitializers);
    })();
    return ShowModeComponent = _classThis;
})();
exports.ShowModeComponent = ShowModeComponent;
