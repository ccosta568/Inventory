import { APIGatewayProxyEventV2, APIGatewayProxyStructuredResultV2 } from 'aws-lambda';
import { DocumentClient } from 'aws-sdk/clients/dynamodb';
import { v4 as uuidv4 } from 'uuid';
import dynamo, { TABLE_NAME } from '../lib/dynamo';
import { requireUserId } from '../lib/auth';
import { badRequest, created, noContent, ok, serverError, unauthorized } from '../lib/http';
import { BookInput, BookRecord } from '../lib/models';
import { bookPartition, bookSortKey } from '../lib/keys';

type BookPayload = BookInput & { copies?: number; delta?: number };

function parseBody<T>(event: APIGatewayProxyEventV2): T | null {
  if (!event.body) return null;
  try {
    return JSON.parse(event.body) as T;
  } catch (err) {
    console.error('Failed to parse body', err);
    return null;
  }
}

function toClientBook(item?: BookRecord | DocumentClient.AttributeMap | null) {
  if (!item) return null;
  const copies = Number((item as BookRecord).copiesOnHand ?? 0);
  return {
    id: (item as BookRecord).bookId,
    title: (item as BookRecord).title,
    author: (item as BookRecord).author,
    format: (item as BookRecord).format,
    price: (item as BookRecord).price,
    copies,
    copiesOnHand: copies,
    notes: (item as BookRecord).notes,
    createdAt: (item as BookRecord).createdAt,
    updatedAt: (item as BookRecord).updatedAt
  };
}

async function listBooks(ownerId: string) {
  const res = await dynamo
    .query({
      TableName: TABLE_NAME,
      KeyConditionExpression: 'PK = :pk',
      ExpressionAttributeValues: { ':pk': bookPartition(ownerId) }
    })
    .promise();

  const books = (res.Items || [])
    .map((item) => toClientBook(item))
    .filter((book): book is NonNullable<ReturnType<typeof toClientBook>> => !!book);
  return ok(books);
}

async function createBook(ownerId: string, event: APIGatewayProxyEventV2) {
  const payload = parseBody<BookPayload>(event);
  if (!payload || !payload.title?.trim()) {
    return badRequest('Title is required');
  }

  const now = new Date().toISOString();
  const bookId = uuidv4();
  const copies = Number(payload.copiesOnHand ?? payload.copies ?? 0) || 0;

  const item: BookRecord = {
    PK: bookPartition(ownerId),
    SK: bookSortKey(bookId),
    entityType: 'BOOK',
    ownerId,
    bookId,
    title: payload.title.trim(),
    author: payload.author?.trim(),
    format: payload.format ?? 'paperback',
    price: Number(payload.price ?? 0),
    copiesOnHand: copies,
    notes: payload.notes ?? '',
    createdAt: now,
    updatedAt: now
  };

  await dynamo
    .put({
      TableName: TABLE_NAME,
      Item: item
    })
    .promise();

  return created(toClientBook(item));
}

async function updateBook(ownerId: string, bookId: string, event: APIGatewayProxyEventV2) {
  const payload = parseBody<Partial<BookPayload>>(event) || {};
  if (payload.copies !== undefined && payload.copiesOnHand === undefined) {
    payload.copiesOnHand = payload.copies;
  }

  const updates: string[] = [];
  const names: DocumentClient.ExpressionAttributeNameMap = {};
  const values: DocumentClient.ExpressionAttributeValueMap = {};
  const now = new Date().toISOString();

  const allowed: (keyof BookPayload)[] = ['title', 'author', 'format', 'price', 'copiesOnHand', 'notes'];
  for (const key of allowed) {
    const value = payload[key];
    if (value !== undefined) {
      const name = `#${key}`;
      const val = `:${key}`;
      updates.push(`${name} = ${val}`);
      names[name] = key;
      values[val] = key === 'title' && typeof value === 'string' ? value.trim() : value;
    }
  }

  if (!updates.length) {
    return badRequest('No valid fields to update');
  }

  updates.push('#updatedAt = :updatedAt');
  names['#updatedAt'] = 'updatedAt';
  values[':updatedAt'] = now;

  const res = await dynamo
    .update({
      TableName: TABLE_NAME,
      Key: {
        PK: bookPartition(ownerId),
        SK: bookSortKey(bookId)
      },
      UpdateExpression: 'SET ' + updates.join(', '),
      ExpressionAttributeNames: names,
      ExpressionAttributeValues: values,
      ReturnValues: 'ALL_NEW'
    })
    .promise();

  return ok(toClientBook(res.Attributes as BookRecord));
}

async function deleteBook(ownerId: string, bookId: string) {
  await dynamo
    .delete({
      TableName: TABLE_NAME,
      Key: {
        PK: bookPartition(ownerId),
        SK: bookSortKey(bookId)
      }
    })
    .promise();

  return noContent();
}

async function adjustStock(ownerId: string, bookId: string, event: APIGatewayProxyEventV2) {
  const payload = parseBody<BookPayload>(event);
  const delta = Number(payload?.delta ?? 0);

  if (!Number.isFinite(delta) || delta === 0) {
    return badRequest('delta must be a non-zero number');
  }

  const res = await dynamo
    .update({
      TableName: TABLE_NAME,
      Key: {
        PK: bookPartition(ownerId),
        SK: bookSortKey(bookId)
      },
      UpdateExpression:
        'SET copiesOnHand = if_not_exists(copiesOnHand, :zero) + :delta, #updatedAt = :updatedAt',
      ExpressionAttributeNames: { '#updatedAt': 'updatedAt' },
      ExpressionAttributeValues: {
        ':delta': delta,
        ':zero': 0,
        ':updatedAt': new Date().toISOString()
      },
      ReturnValues: 'ALL_NEW'
    })
    .promise();

  return ok(toClientBook(res.Attributes as BookRecord));
}

export const handler = async (
  event: APIGatewayProxyEventV2
): Promise<APIGatewayProxyStructuredResultV2> => {
  try {
    const ownerId = requireUserId(event);
    const method = event.requestContext.http?.method?.toUpperCase() ?? '';
    const path = event.rawPath ?? '';
    const bookId = event.pathParameters?.['id'];

    if (method === 'GET' && path === '/books') {
      return await listBooks(ownerId);
    }
    if (method === 'POST' && path === '/books') {
      return await createBook(ownerId, event);
    }
    if (method === 'PUT' && bookId) {
      return await updateBook(ownerId, bookId, event);
    }
    if (method === 'DELETE' && bookId && !path.endsWith('/adjust-stock')) {
      return await deleteBook(ownerId, bookId);
    }
    if (method === 'POST' && bookId && path.endsWith('/adjust-stock')) {
      return await adjustStock(ownerId, bookId, event);
    }

    return badRequest('Unsupported route');
  } catch (err: any) {
    console.error('books handler error', err);
    const message = err?.message || 'Internal error';
    if (message === 'Unauthorized') {
      return unauthorized();
    }
    return serverError(message);
  }
};
