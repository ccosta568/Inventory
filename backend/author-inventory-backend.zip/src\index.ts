export { handler } from './handlers/books';
